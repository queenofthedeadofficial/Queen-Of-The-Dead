/*:
 * @plugindesc Transparent gauges + two-row HP/MP inline on sprite overlay (YEP-safe, stable version)
 * @author
 *
 * @param HP/MP Font Size
 * @type number
 * @min 1
 * @desc Font size for HP/MP labels and values
 * @default 19
 *
 * @param HP/MP Outline Width
 * @type number
 * @min 0
 * @decimals 1
 * @desc Boldness of the text outline (0 = no outline, higher = thicker)
 * @default 5
 *
 * @help
 * This plugin draws HP/MP stats on two rows (HP on top, MP on bottom)
 * on a sprite overlay. Each row has its label left-aligned and its
 * current/max value right-aligned within ROW_WIDTH.
 * Hides overlay during YEP_VictoryAftermath scenes.
 */
(function() {
"use strict";

var parameters = PluginManager.parameters('InlineHPMP_SpriteOverlay');
var hpmpFontSize = Number(parameters['HP/MP Font Size'] || 19);
var hpmpOutlineWidth = Number(parameters['HP/MP Outline Width'] || 2.5);

//
// --------------------------------------------------
// CONFIG (EDIT HERE)
// --------------------------------------------------
//
var OFFSET_X = 30;
var OFFSET_Y = 13;  // Move higher on screen
var ROW_WIDTH = 120;   // Total width of each row (label left-aligned at 0, value right-aligned at this width)
var ROW_SPACING = 0;   // Vertical gap between the HP row and the MP row

//
// --------------------------------------------------
// COLOR CONFIG
// --------------------------------------------------
//
var COLORS = {
    hpLabel: '#b0ff90',
    hpValue: '#ffffff',
    mpLabel: '#8cfffb',
    mpValue: '#ffffff'
};

//
// --------------------------------------------------
// GAUGE TRANSPARENCY ONLY
// --------------------------------------------------
//
var _drawGauge = Window_Base.prototype.drawGauge;
Window_Base.prototype.drawGauge = function(x, y, width, rate, color1, color2) {
    color1 = 'rgba(0,0,0,0)';
    color2 = 'rgba(0,0,0,0)';
    _drawGauge.call(this, x, y, width, rate, color1, color2);
};
Window_Base.prototype.gaugeBackColor = function() {
    return 'rgba(0,0,0,0)';
};

//
// --------------------------------------------------
// DISABLE DEFAULT HP/MP DRAWS
// --------------------------------------------------
//
// Hook Window_BattleStatus.drawGaugeAreaWithTp to prevent gauge drawing
var _Window_BattleStatus_drawGaugeAreaWithTp = Window_BattleStatus.prototype.drawGaugeAreaWithTp;
Window_BattleStatus.prototype.drawGaugeAreaWithTp = function(index, x, y) {
    // Don't draw anything - overlay handles it
};

// Also override drawGaugeArea if it exists
if (Window_BattleStatus.prototype.drawGaugeArea) {
    var _Window_BattleStatus_drawGaugeArea = Window_BattleStatus.prototype.drawGaugeArea;
    Window_BattleStatus.prototype.drawGaugeArea = function(index, x, y) {
        // Don't draw anything - overlay handles it
    };
}

// Disable the base methods too
Window_Base.prototype.drawActorHp = function() {};
Window_Base.prototype.drawActorMp = function() {};

//
// --------------------------------------------------
// SCENE_BATTLE INITIALIZATION
// --------------------------------------------------
//
var _Scene_Battle_initialize = Scene_Battle.prototype.initialize;
Scene_Battle.prototype.initialize = function() {
    _Scene_Battle_initialize.call(this);
    this._hpmpOverlaySprite = null;
    this._messageWasActive = false;
};

var _Scene_Battle_createDisplayObjects = Scene_Battle.prototype.createDisplayObjects;
Scene_Battle.prototype.createDisplayObjects = function() {
    _Scene_Battle_createDisplayObjects.call(this);
    this.createHPMPOverlaySprite();
};

Scene_Battle.prototype.createHPMPOverlaySprite = function() {
    // Create a single sprite covering the entire screen for all HP/MP displays
    this._hpmpOverlaySprite = new Sprite();
    this._hpmpOverlaySprite.bitmap = new Bitmap(Graphics.width, Graphics.height);
    this._hpmpOverlaySprite.z = 10; // Above windows but below popups
    this._hpmpOverlaySprite.visible = true;
    this.addChild(this._hpmpOverlaySprite);
};

var _Scene_Battle_update = Scene_Battle.prototype.update;
Scene_Battle.prototype.update = function() {
    _Scene_Battle_update.call(this);
    this.updateHPMPOverlay();
};

Scene_Battle.prototype.updateHPMPOverlay = function() {
    if (!this._hpmpOverlaySprite) return;
    
    var statusWindow = this._statusWindow;
    if (!statusWindow) {
        this._hpmpOverlaySprite.visible = false;
        return;
    }
    
    // Hide when skill, item, or ADRI enemy scan windows are active
    var skillWindowActive = this._skillWindow && this._skillWindow.active;
    var itemWindowActive = this._itemWindow && this._itemWindow.active;
    var inBattleEnemyStateListActive = this._inBattleEnemyStateList && this._inBattleEnemyStateList.active;
    
    // Hide during victory aftermath (YEP_VictoryAftermath)
    var inVictoryPhase = BattleManager.isVictoryPhase && BattleManager.isVictoryPhase();
    
    // Hide during/after battle end (during transition back to map)
    var battleEnded = !BattleManager.isBattleTest && BattleManager._battlePhase === 'battleEnd';
    var sceneChanging = SceneManager.isSceneChanging();
    
    // Track message activity - once a message appears, stay hidden for a brief grace period
    var messageActive = $gameMessage && ($gameMessage.isBusy() || ($gameMessage._texts && $gameMessage._texts.length > 0));
    if (messageActive) {
        this._messageWasActive = true;
        this._messageGracePeriod = 5; // 5 frames of grace period after message ends
    }
    
    // Decrement grace period
    if (this._messageGracePeriod > 0) {
        this._messageGracePeriod--;
    }
    
    var textBoxHidden = this._messageWasActive && (messageActive || this._messageGracePeriod > 0);
    
    var shouldHide = skillWindowActive || itemWindowActive || inBattleEnemyStateListActive || inVictoryPhase || battleEnded || sceneChanging || textBoxHidden;
    
    this._hpmpOverlaySprite.visible = !shouldHide;
    
    if (!shouldHide) {
        // Clear and redraw all HP/MP (always draw, visibility controlled separately)
        this._hpmpOverlaySprite.bitmap.clear();
        
        var battleMembers = $gameParty.battleMembers();
        
        for (var i = 0; i < battleMembers.length; i++) {
            this.drawActorHPMPOnOverlay(i, statusWindow);
        }
    } else {
        this._hpmpOverlaySprite.bitmap.clear();
    }
};

Scene_Battle.prototype.drawActorHPMPOnOverlay = function(index, statusWindow) {
    var actor = $gameParty.battleMembers()[index];
    if (!actor) return;
    
    var bitmap = this._hpmpOverlaySprite.bitmap;
    var itemRect = statusWindow.itemRect(index);
    
    // Get the absolute position of the status window
    var windowX = statusWindow.x;
    var windowY = statusWindow.y;
    
    // Position relative to item rect
    var screenX = windowX + itemRect.x + OFFSET_X;
    var screenY = windowY + itemRect.y + itemRect.height + OFFSET_Y;
    
    // Use direct canvas rendering
    var ctx = bitmap._context;
    ctx.save();
    
    ctx.font = hpmpFontSize + 'px Jersey10-Regular';
    ctx.textBaseline = 'top';
    
    var rowHeight = hpmpFontSize + ROW_SPACING;
    var hpRowY = screenY;
    var mpRowY = screenY + rowHeight;
    var rightEdge = screenX + ROW_WIDTH;
    
    // HP LABEL (left-aligned)
    ctx.textAlign = 'left';
    ctx.strokeStyle = 'black';
    ctx.lineWidth = hpmpOutlineWidth;
    ctx.fillStyle = COLORS.hpLabel;
    var hpLabel = TextManager.hpA;
    ctx.strokeText(hpLabel, screenX, hpRowY);
    ctx.fillText(hpLabel, screenX, hpRowY);
    
    // HP VALUE (right-aligned)
    ctx.textAlign = 'right';
    ctx.strokeStyle = 'black';
    ctx.lineWidth = hpmpOutlineWidth;
    ctx.fillStyle = COLORS.hpValue;
    var hpValue = actor.hp + '/' + actor.mhp;
    ctx.strokeText(hpValue, rightEdge, hpRowY);
    ctx.fillText(hpValue, rightEdge, hpRowY);
    
    // MP LABEL (left-aligned)
    ctx.textAlign = 'left';
    ctx.strokeStyle = 'black';
    ctx.lineWidth = hpmpOutlineWidth;
    ctx.fillStyle = COLORS.mpLabel;
    var mpLabel = TextManager.mpA;
    ctx.strokeText(mpLabel, screenX, mpRowY);
    ctx.fillText(mpLabel, screenX, mpRowY);
    
    // MP VALUE (right-aligned)
    ctx.textAlign = 'right';
    ctx.strokeStyle = 'black';
    ctx.lineWidth = hpmpOutlineWidth;
    ctx.fillStyle = COLORS.mpValue;
    var mpValue = actor.mp + '/' + actor.mmp;
    ctx.strokeText(mpValue, rightEdge, mpRowY);
    ctx.fillText(mpValue, rightEdge, mpRowY);
    
    ctx.restore();
};

})();
