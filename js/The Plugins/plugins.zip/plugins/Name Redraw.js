/*:
 * @plugindesc Independent party name overlay (no clipping, no YEP interference)
 * Hides names during YEP_VictoryAftermath scenes.
 */

(function() {
"use strict";

let _sprite = null;

const _create = Scene_Battle.prototype.create;
Scene_Battle.prototype.create = function() {
    _create.call(this);
    this.createNameLayer();
};

Scene_Battle.prototype.createNameLayer = function() {
    _sprite = new Sprite(new Bitmap(Graphics.width, Graphics.height));
    _sprite.z = 9999;
    this.addChild(_sprite);
};

const _update = Scene_Battle.prototype.update;
Scene_Battle.prototype.update = function() {
    _update.call(this);
    this.updateNameLayer();
};

Scene_Battle.prototype.updateNameLayer = function() {
    if (!_sprite) return;

    // Hide during victory aftermath (YEP_VictoryAftermath)
    const inVictoryPhase = BattleManager.isVictoryPhase && BattleManager.isVictoryPhase();
    
    if (inVictoryPhase) {
        _sprite.bitmap.clear();
        _sprite.visible = false;
        return;
    }
    
    _sprite.visible = true;

    const bmp = _sprite.bitmap;
    bmp.clear();

    const members = $gameParty.battleMembers();
    const statusWindow = SceneManager._scene._statusWindow;
    if (!statusWindow) return;

    const FONT_SIZE = 18;
    const OFFSET_Y = -26;

    for (let i = 0; i < members.length; i++) {
        const actor = members[i];
        if (!actor) continue;

        const rect = statusWindow.itemRect(i);

        const x = rect.x;
        const y = rect.y + OFFSET_Y;

        bmp.fontSize = FONT_SIZE;
        bmp.textColor = "#ffffff";

        bmp.drawText(actor.name(), x, y, rect.width, 24, "center");
    }
};

})();
